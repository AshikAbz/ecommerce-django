from django.shortcuts import render, redirect
from .models import order, OrderedItem
from products.models import product
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.
def show_cart(request):
    user = request.user  # TO GET USER OBJECT
    customer = user.customer_profile
    cart_obj, created = order.objects.get_or_create(  # CREATE CART OBJECT TO GET OWNER CUSTOMER AND ORDER_STATUS BY LOOKING MODEL
        owner=customer,  # here owner is our customer
        order_status=order.CART_STAGE  # order_status have to CART_STAGE (0)
    )
    context = {'cart': cart_obj}
    return render(request, 'cart.html', context)  # Pass the context to the render function

def remove_item_from_cart(request,pk):
    item=OrderedItem.objects.get(pk=pk)
    if item:
        item.delete()
    return redirect('cart')

def confirm_order(request):
    if request.POST:
        try:
            user = request.user  # TO GET USER OBJECT
            customer = user.customer_profile  # TO TAKE CUSTOMER USING USER OBJECT
            total = float(request.POST.get('total'))  # get and TO KNOW QUANTITY
            print(total)
            order_obj = order.objects.get(  # CREATE CART OBJECT TO GET OWNER CUSTOMER AND ORDER_STATUS BY LOOKING MODEL
                owner=customer,  # here owner is our customer
                order_status=order.CART_STAGE  # order_status have to CART_STAGE (0)
            ) 
            if order_obj:
                order_obj.order_status = order.ORDER_CONFIRMED  # to convert to order confirmed
                order_obj.total_price=total 
                # print(total)                    #pass total to here from getting part above
                order_obj.save()
                statuss_message = "Your order is processed. Your item will be delivered within one week."
                messages.success(request, statuss_message)
            else:
                error_message = "Unable to process. No items in cart again."
                messages.error(request, error_message)
        except Exception as e:
            error_message = "Unable to process. No items in cart again."
            messages.error(request, error_message)
    return redirect('cart')

@login_required(login_url='account')
def view_orders(request):
    user = request.user  # TO GET USER OBJECT
    customer = user.customer_profile #to get customer by user
    all_orders=order.objects.filter(owner=customer).exclude(order_status=order.CART_STAGE) #to get all orders that exclude or avoid CART_STAGE=0 order only
    context={'order':all_orders}
    print(all_orders)

    return render(request,'order.html',context)  # Pass the context to the render function

@login_required(login_url='account') #if user login then only  move on to below function
def add_to_cart(request):
    if request.POST:
        user=request.user              #TO GET USER OBJECT
        customer=user.customer_profile # TO TAKE CUSTOMER USING USER OBJECT
        quantity=int(request.POST.get('quantity')) #TO KNOW QUANTITY
        product_id=request.POST.get('product_id') #TO GET PRODUCT ID
        cart_obj,created=order.objects.get_or_create(  #CRERATE CART OBJECT TO GET  OWNER CUSTOMER AND ORDER_STATUS BY LOOKING MODEL
        owner=customer,                                 #here owner is our customer
        order_status=order.CART_STAGE                   #order_status have to CART_STAGE (0)
          ) 
     #then add OrderedItem into cart
        Product=product.objects.get(pk=product_id)
        ordereditem,created=OrderedItem.objects.get_or_create(   #to take existing product from OrderedItems from model,get_or_create function used to value has not available there will be create a default cart value
            product=Product,
            owner=cart_obj,
            quantity=quantity
        )
        if created:   #this condition use for when we add into cart multiple timme the quantity of product increasing 
            ordereditem.quantity=quantity
            ordereditem.save()
        else:
            ordereditem.quantity=ordereditem.quantity+quantity
            ordereditem.save()
        return redirect('cart')