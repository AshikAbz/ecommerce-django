from django.contrib import admin
from orders.models import order,OrderedItem

# Register your models here.
admin.site.register(order)
admin.site.register(OrderedItem)