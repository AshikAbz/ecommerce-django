from django.shortcuts import render,get_object_or_404
from . models import product
from django.core.paginator import Paginator





# Create your views here.
def index(request):
    futured_products = product.objects.order_by('priority')[:4]  #took product details by priority and show first four img product
    latest_products = product.objects.order_by('id')[:4]
    context={
        'futured_products':futured_products,    
        'latest_products':latest_products

    }
    return render(request,'index.html',context)

def list_products(request):
    page=1          #default page 1
    if request.GET:                     #here if request.GET have value this value take
        page=request.GET.get('page',1)# take page 
    list_product = product.objects.order_by('priority')  #here all backend data takes and store in list_product,here take data by order_by field with priority argument
    product_paginator=Paginator(list_product,4)  #here we give for Paginator class argument 1.which records or list paginator 2.each page reqiered count
    list_product=product_paginator.get_page(page)
    context = {'products': list_product}   #save backend typing data into context by using dictionary
    return render(request, 'products.html', context)


 
def product_details(request,pk):
    products=product.objects.get(pk=pk)
    context={'product':products}
    return render(request,'product_details.html',context)

