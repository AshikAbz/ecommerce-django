from django.db import models

#Model For product
class product(models.Model):
    LIVE=1      #DECLARE INTEGER VALUE   *TO DELETED DATA STORE CACHE
    DELETE=0     #DECLARE INTEGER VALUE
    DELETE_CHOICES=((LIVE,'Live'),(DELETE,'Delete'))  #BOTH INTEGER VALUE GIVE AS A CHOICES   *DELETED DATA STORE CACHE
    Title=models.CharField(max_length=200)
    price=models.FloatField()
    description=models.TextField()
    image=models.ImageField(upload_to='images/') #to show image field like flipkart app
    priority=models.IntegerField(default=0) # items shown based oe=wn priority
    delete_status =models.IntegerField(choices=DELETE_CHOICES,default=LIVE) #TO INDICATE DELETE STATUS,HERE DEFAULT VALUE BECOME LIVE  *DELETED DATA STORE IN CACHE
    created_at=models.DateTimeField(auto_now_add=True) #OUR NEW DATA CREATED TIME UPDATION
    updated_at=models.DateTimeField(auto_now=True)   #OUR NEW DATA UPDATED TIME SHOW

    def  __str__(self) -> str:
        return self.Title





    
