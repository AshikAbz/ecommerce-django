from django.shortcuts import render, redirect
from django.contrib.auth.models import User #to use django default user
from django.contrib.auth import authenticate,login,logout
from .models import customers  #import customer class from customer's model
from django.contrib import messages #import django default messages to print errormessage or etc like info,success etc

# Create your views here.
    
def singn_out(request):
    logout(request)
    return redirect ('home')
def account(request): 
    error_message = None
    context={}  #declared a dictionary to store data of register button or login button
    if request.method == 'POST' and 'register' in request.POST: #check user posted value and button is register 
        context['register']=True   #give True value for register button 
        
        try:
            username = request.POST.get('username') #to get all fields
            password = request.POST.get('password')
            email = request.POST.get('email')
            address = request.POST.get('address')
            phone = request.POST.get('phone')

            # Create user account
            users = User.objects.create_user(  #TO CREATE USER OBJECT
                username=username,
                password=password,
                email=email
            )

            # Create customer account
            customer = customers.objects.create(
                name=username,
                user=users,
                phone=phone,
                address=address
            )
            success_message="User Registered Successfully"
            messages.success(request,success_message)
                     
        except Exception as e:
            error_message = "Duplicate username or invalid credentials"
            messages.error(request,error_message)
    if request.method == 'POST' and 'login' in request.POST: #check user posted value and button is login
        context['register']=False    #give value value for register button 
        username = request.POST.get('username') #to get all fields
        password = request.POST.get('password')
        user=authenticate(username=username,password=password) #use authenticate function to check user existing for given username and password and user existing an user object return
        if user:     #if user exist
            login(request,user)   #login use available user object
            return redirect('home')
        else:
          messages.error(request,'Invalid User')

    return render(request, 'account.html',context)
