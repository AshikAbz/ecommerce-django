from django.db import models
from django.contrib.auth.models import User  #Here we import django default user from contrib.auth

# Create your models here.
class customers(models.Model):  #in this customer field we want signup,login,logout
    LIVE=1      #DECLARE INTEGER VALUE   *TO DELETED DATA STORE CACHE
    DELETE=0     #DECLARE INTEGER VALUE
    DELETE_CHOICES=((LIVE,'Live'),(DELETE,'Delete'))  #BOTH INTEGER VALUE GIVE AS A CHOICES   *DELETED DATA STORE CACHE
    name=models.CharField(max_length=220)
    address=models.TextField()
    user=models.OneToOneField(User,on_delete=models.CASCADE,related_name='customer_profile')  #when create a customera account also create an user model.
    phone=models.CharField(max_length=10)
    delete_status =models.IntegerField(choices=DELETE_CHOICES,default=LIVE) #TO INDICATE DELETE STATUS,HERE DEFAULT VALUE BECOME LIVE  *DELETED DATA STORE IN CACHE
    created_at=models.DateTimeField(auto_now_add=True) #OUR NEW DATA CREATED TIME UPDATION
    updated_at=models.DateTimeField(auto_now=True)   #OUR NEW DATA UPDATED TIME SHOW

    def __str__(self) -> str:
        return self.user.username